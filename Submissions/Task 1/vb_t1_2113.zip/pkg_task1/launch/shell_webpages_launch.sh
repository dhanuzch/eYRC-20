#!/bin/bash
echo "  "
echo "  "
echo "  "
echo "  "
echo "  "
echo "
╦ ╦┌─┐┬ ┬    ┌─┐┬─┐┌─┐    ┌┐ ┬─┐┌─┐┌─┐┌┬┐┬ ┬┌┬┐┌─┐┬┌─┬┌┐┌┌─┐
╚╦╝│ ││ │    ├─┤├┬┘├┤     ├┴┐├┬┘├┤ ├─┤ │ ├─┤ │ ├─┤├┴┐│││││ ┬
 ╩ └─┘└─┘    ┴ ┴┴└─└─┘    └─┘┴└─└─┘┴ ┴ ┴ ┴ ┴ ┴ ┴ ┴┴ ┴┴┘└┘└─┘
"
echo "                  -Keanu Reeves '19                         "
echo "  "
echo "  "
echo "  "
echo "  "
echo "eyrc/UaHaYix/iot_to_ros"
echo "eyrc/UaHaYix/ros_to_iot"
echo "  "
echo "  "
echo "  "
echo "  "
echo "   "
URL1="http://www.hivemq.com/demos/websocket-client/"
URL2="https://docs.google.com/spreadsheets/d/1Uox6FmBoksQ6PMgTeHXfvXyJiQDvLVTw0i0XoIE4ytU/edit?usp=sharing"
firefox -new-window $URL1 $URL2
 